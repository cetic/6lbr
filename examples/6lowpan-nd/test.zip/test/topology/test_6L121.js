// load(../lib.js)

//Display NC when changement of msg was done
TIMEOUT(7200000); //2h
WaitingStarting();

log.log("Modify RT\n");
buildRT([
    {"mote":2, 
     "fct":function(){
        addroute(1,4,2,128);
        addroute(1,3,2,128);
        }
    },
    {"mote":4, 
     "fct":function(){
         addroute(2,3,4,128);
         }
    }
]);

for(var i=0; i<=15; i++) {
	waitingConfig();
	log.log("Topology stable\n");
	displayAllTable();
	log.log("Sending udp packet\n");
	sendudpBR(brID);
    log.log("...OK"+i+"\n");
}
log.testOK();